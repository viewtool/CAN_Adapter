/** Automatically generated file. DO NOT MODIFY */
package viewtool.usb_pwm_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}