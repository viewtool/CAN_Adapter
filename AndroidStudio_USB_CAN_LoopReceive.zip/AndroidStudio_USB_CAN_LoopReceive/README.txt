fixed:
 crash when read data too fast