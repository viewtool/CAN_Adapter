/** Automatically generated file. DO NOT MODIFY */
package com.viewtool.usb_adc_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}