/** Automatically generated file. DO NOT MODIFY */
package com.viewtool.wdluo.usb_adc_pulsesensor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}