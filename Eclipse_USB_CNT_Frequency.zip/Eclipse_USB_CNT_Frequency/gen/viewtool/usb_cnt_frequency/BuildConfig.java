/** Automatically generated file. DO NOT MODIFY */
package viewtool.usb_cnt_frequency;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}