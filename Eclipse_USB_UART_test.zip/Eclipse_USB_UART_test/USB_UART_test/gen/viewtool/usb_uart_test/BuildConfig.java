/** Automatically generated file. DO NOT MODIFY */
package viewtool.usb_uart_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}